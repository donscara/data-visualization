"""
# D7055E - Assigment 3 - Challenging Questions
## Group 6
*   Donato Scarano - DONSCA-3
*   Jacob Yousif - JACYOU-0
*   Yuehua Qin - YUEQIN-9
"""

import cv2


"""## Challenging Questions

### Q1
"""
fileName = 'output_detection.avi'
imgSize = (640, 480)
frame_per_second = 30.0
writer = cv2.VideoWriter(fileName, cv2.VideoWriter_fourcc(*"MJPG"), frame_per_second, imgSize)

cap = cv2.VideoCapture(0)
while(cap.isOpened()):
    ret, frame = cap.read()
    if ret:
        frame_smoothed = cv2.GaussianBlur(frame, (5, 5), 0)
        edges = cv2.Canny(frame_smoothed, 20, 60, apertureSize=3) 
        edges_colored = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
        writer.write(edges_colored)
        cv2.imshow('Edges', edges_colored)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    else:
        break
cap.release()
writer.release()
cv2.destroyAllWindows()



"""
Q2
Laplacian and Sobel methods are used in image processing, i.e. edge detection. 
The Laplacian method focuses on the areas that have rapid intensity changes. It may detect false edges in noisy images. 
The Sobel method uses convolution with Sobel kernels. This method is less sensitive to noise compared to the Laplacian. 
"""


"""
### Q3
"""

cap = cv2.VideoCapture(0)
ret, frame = cap.read()
fileName = 'output_with_mask.avi'
frame_per_second = 30.0
imgSize = (frame.shape[1], frame.shape[0])
writer = cv2.VideoWriter(fileName, cv2.VideoWriter_fourcc(*"MJPG"), frame_per_second, imgSize)

while ret:
    blurred_frame = cv2.GaussianBlur(frame, (5, 5), 0)
    edges = cv2.Canny(blurred_frame, 100, 200)
    mask_inv = cv2.bitwise_not(edges)
    mask_inv_colored = cv2.cvtColor(mask_inv, cv2.COLOR_GRAY2BGR)
    result = cv2.bitwise_and(frame, mask_inv_colored)
    writer.write(result)
    cv2.imshow('Superimposed Image', result)
    ret, frame = cap.read()
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cap.release()
writer.release()
cv2.destroyAllWindows()


"""
### Q4
Besides the required initialization procedures, the first procedure is to capture the video. 
Then the solution goes through the frames of the video by looping the object and it applies background 
subtraction on the frames to obtain foreground masks to detect moving objects. 
"""


"""
### Q5
"""
backSub = cv2.createBackgroundSubtractorMOG2()
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break
    fgMask = backSub.apply(frame)

    cv2.imshow('Frame', frame)
    cv2.imshow('Foreground mask', fgMask)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
