# -*- coding: utf-8 -*-
"""
Created on Mon Nov 20 21:09:14 2023

@author: donsc
"""

# import packages and libraries
import folium
import reverse_geocoder
import seaborn
import sklearn
import imblearn

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#read the datasets files
zeroaccess_df = pd.read_csv("zeroaccess.csv")
state_df = pd.read_csv("state-internets.csv")
county_df = pd.read_csv("county-data.csv")

#print the shape of the datasets
print(zeroaccess_df.shape, state_df.shape, county_df.shape)

#print the head of the data
print(zeroaccess_df.head())
print(state_df.head())
print(county_df.head())

#plot the ZeroAccess infection instances on an instance of the world map.
fig = plt.figure(figsize=(8,6))
ax=fig.add_subplot(111)

ax.scatter(zeroaccess_df.long, zeroaccess_df.lat, alpha=0.1, s=1, label="zeroAccess")
ax.set_xlim((-180,180))
ax.set_ylim((-90,90))

plt.xlabel("Latitude and Longitude")
plt.ylabel("Latitude and Longitude")
plt.legend(loc="upper left")

plt.show()

