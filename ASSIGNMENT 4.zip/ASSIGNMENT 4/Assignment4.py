# -*- coding: utf-8 -*-

# ZERO ACCESS CYBER ATTACK

# import packages and libraries
import folium
import reverse_geocoder
import seaborn
import sklearn
import imblearn

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#read the datasets files
zeroaccess_df = pd.read_csv("zeroaccess.csv")
state_df = pd.read_csv("state-internets.csv")
county_df = pd.read_csv("county-data.csv")

#print the shape of the datasets
print(zeroaccess_df.shape, state_df.shape, county_df.shape)

#print the head of the data
print(zeroaccess_df.head())
print(state_df.head())
print(county_df.head())

#plot the ZeroAccess infection instances on an instance of the world map.
fig = plt.figure(figsize=(8,6))
ax=fig.add_subplot(111)

ax.scatter(zeroaccess_df.long, zeroaccess_df.lat, alpha=0.1, s=1, label="zeroAccess")
ax.set_xlim((-180,180))
ax.set_ylim((-90,90))

plt.xlabel("Latitude and Longitude")
plt.ylabel("Latitude and Longitude")
plt.legend(loc="upper left")

plt.show()

#produce heatmap of the world based on the infection rate
from folium.plugins import HeatMap
mapa = folium.Map(location=(10,10),zoom_start=1.5,tiles="Stamen Toner", height="50%", width="50%")
loc_li = list(zip(list(zeroaccess_df.lat),(zeroaccess_df.long)))[:10000]
HeatMap(loc_li,radius=15).add_to(mapa)
mapa

#batch implementation  getting only the first 50000 rows and printing the dataframe
def rgr_batch(lat_long_df):
    cord_li = []
    for ind in lat_long_df.index:
        cord_li.append((lat_long_df['lat'][ind], lat_long_df['long'][ind]))
    result_dict_li = reverse_geocoder.search(cord_li)
    return pd.DataFrame(result_dict_li).drop(['lat', 'lon'], axis = 1)

sample_df = zeroaccess_df.head(50000)
country_df = rgr_batch(sample_df)
df=sample_df.join(country_df).rename(columns={'name':'City', 'admin1':'State','admin2':'County','cc':'country_code',})
df

#plot figure of the number of attacks in each country

country_num = df.groupby(['country_code']).size().sort_values(ascending=False)
country_num = country_num[country_num.values>100]
plt.figure(figsize=(16,3))
plt.bar(country_num.index, country_num.values, width=0.6)
plt.xticks(rotation='vertical')
plt.show()

#plot figure of the percentage of attacks in each country

country_counts = df['country_code'].value_counts(normalize=True)
country_counts = country_counts[country_counts.values>0.01]

plt.figure(figsize=(16,3))
plt.bar(country_counts.index, country_counts.values, width=0.6)
plt.xticks(rotation='vertical')
plt.show()

country_counts

#create a dataframe for the US
us_df = df[df['country_code']=='US']
us_df

#plot zeroAccess infection instances on US map
fig=plt.figure(figsize=(8,6))
ax=fig.add_subplot(111)
ax.scatter(us_df.long,us_df.lat, alpha=0.1, s=1)
plt.show()

#show the count for individual stats with more than 30 infections
df.State.value_counts()[df.State.value_counts()>30]

#show the values of cities grouped with their states in descending order
df.groupby(['State','City']).size().sort_values(ascending=False)

#using the county dataset for the prediction of attack counts by state using linear regression

county_df=pd.read_csv('county-data.csv')
county=county_df.groupby('subregion').sum()
a= pd.Series(np.random.rand(1774))
b= pd.Series(np.random.rand(1774))
c= pd.Series(np.random.rand(1774))
d= pd.Series(county.index)
temp={'attack':a,'att_pc': b, 'pop_pc': c, 'subregion': d}
att_pop=pd.DataFrame(temp)
county1=county.merge(att_pop, left_on='subregion', right_on='subregion') #, left_index=True,right_index=True)
county1 = county1.set_index('subregion')

#create a correlation matrix showing correlation coefficients between variables.
co_matrix= county1.corr(numeric_only=True)
co_matrix.style.background_gradient( )

#define axis and run a linear regression on the data

X_train = county1.drop(['attack'],axis=1)
y_train = county1['attack']

from sklearn.linear_model import LinearRegression

linearRegModel = LinearRegression()
linearRegModel.fit(X_train, y_train)

#print the intercept and coefficients
print("Intercept is", linearRegModel.intercept_)
print("coefficients is", linearRegModel.coef_)

#print with feature name

print()
print("attack =")
for c,f in zip(linearRegModel.coef_, X_train.columns):
    print(' {0:+} * {1}'.format(c,f))
print("",linearRegModel.intercept_)

#print the regression summary on the screen

import statsmodels.api as sm
results = sm.OLS(y_train, X_train).fit()
results.summary()

#INTERACTIVE ANALYSIS DASHBOARD: THE COVID-19 USE CASE
#import packages and libraries

from __future__ import print_function
from ipywidgets import interact, interactive, fixed, interact_manual
from IPython.core.display import display, HTML

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
import folium
import plotly.graph_objects as go
import seaborn as sns
import ipywidgets as widgets

# read the dataset files from the Novel Coronavirus Covid-19 Data Repository by John Hopkins University's Center
death_df = pd.read_csv('https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_deaths_global.csv')
confirmed_df = pd.read_csv('https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_confirmed_global.csv')
recovered_df = pd.read_csv('https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_recovered_global.csv')
country_df = pd.read_csv('https://raw.githubusercontent.com/CSSEGISandData/COVID-19/web-data/data/cases_country.csv')

confirmed_df.head()

death_df.head()

recovered_df.head()

country_df.head()

# renaming the dataframe's column names to lowercase
country_df.columns = map(str.lower, country_df.columns)
confirmed_df.columns = map(str.lower, confirmed_df.columns)
death_df.columns = map(str.lower, death_df.columns)
recovered_df.columns = map(str.lower, recovered_df.columns)

#change province/state to state and country/region to country
confirmed_df = confirmed_df.rename(columns={'privince/state': 'state', 'country/region':'country'})
recovered_df = recovered_df.rename(columns={'privince/state': 'state', 'country/region':'country'})
death_df = death_df.rename(columns={'privince/state': 'state', 'country/region':'country'})
country_df = country_df.rename(columns={'country/region':'country'})

country_df.head(10)

# total number of confirmed, death and recoverd cases

confirmed_total = int(country_df['confirmed'].sum())
deaths_total = int(country_df['deaths'].sum())
recovered_total = int(country_df['recovered'].sum())
active_total = int(country_df['active'].sum())

#displaying the total stats
display(HTML("<div style='background-color: #504e4e; padding:30px;'>" +
            "<span style='color: #fff; font-size:30px;'> Confirmed: " + str(confirmed_total) + "</span>" +
            "<span style='color:red; font-size:30px; margin-left:20px;'> Deaths: " + str(deaths_total) + "</span>" +
            "<span style='color:lightgreen; font-size:30px; margin-left:20px;'> Recovered: " + str(recovered_total) + "</span>" +
            "</div>")
)

#sorting the values by confirmed descending order

fig = go.FigureWidget(layout=go.Layout())
def highlight_col(x):
    r = 'background-color: red'
    y = 'background-color: purple'
    g = 'background-color: grey'
    df1 = pd.DataFrame('', index=x.index, columns=x.columns)
    df1.iloc[:, 4] = y
    df1.iloc[:, 5] = r
    df1.iloc[:, 6] = g

    return df1

def show_latest_cases(n):
    n =int(n)
    return country_df.sort_values('confirmed', ascending = False).head(n).style.apply(highlight_col, axis=None)

interact(show_latest_cases, n='10')

ipywLayout = widgets.Layout(border='solid 2px green')
ipywLayout.display='none'
widgets.VBox([fig], layout=ipywLayout)

sorted_country_df = country_df.sort_values('confirmed', ascending = False)

#plotting the 30 most affected countries by Covid19

def bubble_chart(n):
    fig = px.scatter(sorted_country_df.head(n),x="country_region", y="confirmed", size="confirmed", color="country_region",
                     hover_name='country_region', size_max=60)
    fig.update_layout(
    title=str(n)+"Worst hit countries",
    xaxis_title = 'Countries',
    yaxis_title = 'Confirmed Cases',
    width =700
    )
    fig.show();

interact(bubble_chart, n=10)

ipywLayout = widgets.Layout(border='solid 2px green')
ipywLayout.display='none'
widgets.VBox([fig], layout=ipywLayout)

# plot the number of fatalities and confirmed cases on daily basis
def plot_cases_of_a_country(country):
    labels = ['confirmed', 'deaths']
    colors = ['blue', 'red']
    mode_size = [6, 8]
    line_size = [4, 5]

    df_list = [confirmed_df,death_df]

    fig = go.Figure();

    for i, df in enumerate(df_list):
        if country == 'World' or country == 'world':
           x_data = np.array(list(df.iloc[:, 20:].columns))
           y_data = np.sum(np.asarray(df.iloc[:, 4: ]), axis=0)

        else:
           x_data = np.array(list(df.iloc[:, 20:].columns))
           y_data = np.sum(np.asarray(df[df['country'] == country].iloc[:,20:]),axis = 0)
        print(i)
        fig.add_trace(go.Scatter(x=x_data,y=y_data, mode='lines+markers',
                                 name=labels[i],
                                 line=dict(color=colors[i], width=line_size[i]),
                                 connectgaps=True,
                                 text="Total "+str(labels[i])+":"+str(y_data[-1])
                                 ));
    fig.update_layout(title="COVID 19 cases of "+ country,
                      xaxis_title="Date", yaxis_title='No. of Confirmed Cases',
                      margin=dict(l=20, r=20, t=40, b=20),
                      paper_bgcolor='lightgrey', width = 800,
    );

    fig.update_yaxes(type='linear')
    fig.show();

interact(plot_cases_of_a_country, country='World')

ipywLayout = widgets.Layout(border='solid 2px green')
ipywLayout.display='none'
widgets.VBox([fig], layout=ipywLayout)

#plot an interactive bar plot with the actual number of confirmed cases 
px.bar(
    sorted_country_df.head(10),
    x = "country_region",#column name is not country
    y = "confirmed",
    title = "Top 10 worst affected countries based on number of confirmed Covid-19 cases",
    color_discrete_sequence=["pink"],
    height = 500,
    width = 800
)

#drop NAN values from latitude and Longitude columns
confirmed_df = confirmed_df.dropna(subset=['long'])
confirmed_df = confirmed_df.dropna(subset=['lat'])

#plot an interactive leaflet map
world_map = folium.Map(location=[11,0],tiles="cartodbpositron", zoom_start=2, max_zoom=6, min_zoom=2)

for i in range(0, len(confirmed_df)):
    folium.Circle(
        location=[confirmed_df.iloc[i]['lat'],confirmed_df.iloc[i]['long']],
                  fill=True,
                  radius=(int((np.log(confirmed_df.iloc[i,-1]+1.00001)))+0.2)*50000,
                  color='red',
                  fill_color='indigo',
                  tooltip="<div style = 'margin: 0; background-color: black; color:white;'>"+
                          "<h4 style='text-align:center;font-weight:bold'>"+
                  confirmed_df.iloc[i]['country']+"</h4>"
                  "<hr style = 'margin:10px;color:white;'>"+
                  "<ul style = 'color:white;;list-style-type:circle;align-item:left;padding-left:20px;padding-right:20px'>"+
                  "<li>Confirmed: "+str(confirmed_df.iloc[i,-1])+"</li>"+
                  "<li>Deaths: "+str(death_df.iloc[i,-1])+"</li>"+
                  "<li>Death Rate: "+str(np.round(death_df.iloc[i,-1]/(confirmed_df.iloc[i,-1]+1.00001)*100,2))+"</li>"+
                  "</ul></div>",
    ).add_to(world_map)

world_map

# NETWORK INTRUSION DETECTION USING PYTHON
# import relevant modules
%matplotlib inline
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
import sklearn
import imblearn
import sys

# Ignore warnings
import warnings
warnings.filterwarnings('ignore')

# Settings
pd.set_option('display.max_columns', None)
np.set_printoptions(threshold=sys.maxsize)
np.set_printoptions(precision=3)
sns.set(style="darkgrid")
plt.rcParams['axes.labelsize'] = 14
plt.rcParams['xtick.labelsize'] = 12
plt.rcParams['ytick.labelsize'] = 12

train = pd.read_csv("Train1_data.csv")
test = pd.read_csv("Test1_data.csv")

#load data

print(train.head(4))
print("Training data has {} rows & {} columns".format(train.shape[0],train.shape[1]))

print(test.head(4))
print("Testing data has {} rows & {} columns".format(test.shape[0],test.shape[1]))

# Descriptive statistics
train.describe()

#print value counts for train and test 
print(train['num_outbound_cmds'].value_counts())
print(test['num_outbound_cmds'].value_counts())

#'num_outbound_cmds' is a redundant column so remove it from both train & test datasets
train.drop(['num_outbound_cmds'], axis=1, inplace=True)
test.drop(['num_outbound_cmds'], axis=1, inplace=True)

# Attack Class Distribution
train['class'].value_counts()

# Scaling Numerical Attributes

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()

# extract numerical attributes and scale it to have zero mean and unit variance  
cols = train.select_dtypes(include=['float64','int64']).columns
sc_train = scaler.fit_transform(train.select_dtypes(include=['float64','int64']))
sc_test = scaler.fit_transform(test.select_dtypes(include=['float64','int64']))

# turn the result back to a dataframe
sc_traindf = pd.DataFrame(sc_train, columns = cols)
sc_testdf = pd.DataFrame(sc_test, columns = cols)

# Encoding Categorical Attributes
from sklearn.preprocessing import LabelEncoder
encoder = LabelEncoder()

# extract categorical attributes from both training and test sets 
cattrain = train.select_dtypes(include=['object']).copy()
cattest = test.select_dtypes(include=['object']).copy()

# encode the categorical attributes
traincat = cattrain.apply(encoder.fit_transform)
testcat = cattest.apply(encoder.fit_transform)

# separate target column from encoded data 
enctrain = traincat.drop(['class'], axis=1)
cat_Ytrain = traincat[['class']].copy()

train_x = pd.concat([sc_traindf,enctrain],axis=1)
train_y = train['class']
train_x.shape

test_df = pd.concat([sc_testdf,testcat],axis=1)
test_df.shape

# Feature Selection

from sklearn.ensemble import RandomForestClassifier
rfc = RandomForestClassifier();

# fit random forest classifier on the training set
rfc.fit(train_x, train_y);

# extract important features
score = np.round(rfc.feature_importances_,3)
importances = pd.DataFrame({'feature':train_x.columns,'importance':score})
importances = importances.sort_values('importance',ascending=False).set_index('feature')

# plot importances
plt.rcParams['figure.figsize'] = (11, 4)
importances.plot.bar();

from sklearn.feature_selection import RFE
import itertools
rfc = RandomForestClassifier()

# create the RFE model and select 10 attributes
rfe = RFE(rfc, n_features_to_select=15)
rfe = rfe.fit(train_x, train_y)

# summarize the selection of the attributes
feature_map = [(i, v) for i, v in itertools.zip_longest(rfe.get_support(), train_x.columns)]
selected_features = [v for i, v in feature_map if i==True]

selected_features

# Dataset Partition

from sklearn.model_selection import train_test_split

X_train,X_test,Y_train,Y_test = train_test_split(train_x,train_y,train_size=0.70, random_state=2)

# Fitting Models

from sklearn.svm import SVC 
from sklearn.naive_bayes import BernoulliNB 
from sklearn import tree
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression

# Train KNeighborsClassifier Model
KNN_Classifier = KNeighborsClassifier(n_jobs=-1)
KNN_Classifier.fit(X_train, Y_train); 

# Train LogisticRegression Model
LGR_Classifier = LogisticRegression(n_jobs=-1, random_state=0)
LGR_Classifier.fit(X_train, Y_train);

# Train Gaussian Naive Baye Model
BNB_Classifier = BernoulliNB()
BNB_Classifier.fit(X_train, Y_train)
            
# Train Decision Tree Model
DTC_Classifier = tree.DecisionTreeClassifier(criterion='entropy', random_state=0)
DTC_Classifier.fit(X_train, Y_train)

# Evaluate Models
from sklearn import metrics

models = []
models.append(('Naive Baye Classifier', BNB_Classifier))
models.append(('Decision Tree Classifier', DTC_Classifier))
models.append(('KNeighborsClassifier', KNN_Classifier))
models.append(('LogisticRegression', LGR_Classifier))

for i, v in models:
    scores = cross_val_score(v, X_train, Y_train, cv=10)
    accuracy = metrics.accuracy_score(Y_train, v.predict(X_train))
    confusion_matrix = metrics.confusion_matrix(Y_train, v.predict(X_train))
    classification = metrics.classification_report(Y_train, v.predict(X_train))
    print()
    print('============================== {} Model Evaluation =============================='.format(i))
    print()
    print ("Cross Validation Mean Score:" "\n", scores.mean())
    print()
    print ("Model Accuracy:" "\n", accuracy)
    print()
    print("Confusion matrix:" "\n", confusion_matrix)
    print()
    print("Classification report:" "\n", classification) 
    print()
    
for i, v in models:
    accuracy = metrics.accuracy_score(Y_test, v.predict(X_test))
    confusion_matrix = metrics.confusion_matrix(Y_test, v.predict(X_test))
    classification = metrics.classification_report(Y_test, v.predict(X_test))
    print()
    print('============================== {} Model Test Results =============================='.format(i))
    print()
    print ("Model Accuracy:" "\n", accuracy)
    print()
    print("Confusion matrix:" "\n", confusion_matrix)
    print()
    print("Classification report:" "\n", classification) 
    print()  

# PREDICTING FOR TEST DATA using KNN
pred_knn = KNN_Classifier.predict(test_df)
pred_NB = BNB_Classifier.predict(test_df)
pred_log = LGR_Classifier.predict(test_df)
pred_dt = DTC_Classifier.predict(test_df)

# CHALLENGING QUESTIONS

# Q1. Where does ZeroAcess occur? Are there any patterns?
# It seems that infection rates are more concentrated on densely populated and high internet penetration areas such as North America, Europe, South East Asia, Middle East and India.
# It aligns with the more general trend of cyberattacks where dense urban areas serve as hubs for businesses with greater internet connectivity and financial assets that are tempting targets for such type of attacks. 
# But there are also some outliers in the pictures for example Pakistan which is not a developed country but probably is facing low security protection that make it a good target for possible attacks or there is a military and political motivation behind it. 
# There are also other developed countries such as Italy which show outsized ranking based on the weight of their economy and that can indicate a low security issue which make tempting and easier an attack.
# United States represents the larger market for ZeroAccess attacks and we can see from the analysis that also here the densiest urban and financial areas are the main playground for those attacks.

# Q2. Are there any specific types of users that are easily affected? Is education or income affect its infection rate?
# Based on the results of the analysis there is no direct evidence to suggest that a specific type of users is more affected.
# There are cases of both high-income and low-income countries with hight infection rates and viceversa. This could mean that other factors have an influence here such as internet access, security practices and infrastructure.
# There are some trends though that can play a role:
# Higher income individuals may be more likely to access higher speed internet and use multiple devices and therefore be a more attractive target for hackers.
# Education does not seem to be a primary determinant though indirectly more educated individuals are higher earners while low educated individuals may not be aware of cybersecurity issues and these could be factors that may influence the spread of ZeroAccess.

# Q3. Plot a figure to show the number of attacks in the top 5 countries with respect to the number of attacks.

#plot figure of the number of attacks in the top 5 countries with respect to the number of attacks

country_num = df.groupby(['country_code']).size().sort_values(ascending=False)
country_num = country_num[country_num.values.argsort()[-5:][::-1]]
plt.figure(figsize=(16,3))
plt.title("Top 5 Countries by Number of Attacks")
plt.ylabel("Number of Attacks")
plt.xlabel("Country")
plt.bar(country_num.index, country_num.values, width=0.6)
plt.xticks(rotation='vertical')
plt.show()

# Q4. Which state and city have a severe attack? and why? 
# The state with the highest values are Peabody, Kansas London, England , Tokyo and Islamabad.
# For London and Tokyo the results are to be expected, they are both major financial centers and densely populated, highly connected A class cities.
# Peabody, Kansas and Islamabad are a different story.
# Peabody, Kansas is a small rural town of less than 1000 inhabitants there might have been a specific single attack to some key infrastructure, news reported major attacks across Kansas which targeted low security companies and government offices and Peabody could be part of this larger scheme affecting Kansas although more research on the causes is due.
# Islamabad is the capital of Pakistan and although not as developed and affluent as London and Tokyo could have been a desired target for military or political reasons or maybe being a low security country it could be considered a soft target.


# Q5. What do you get from the following code snippet and why? Explain the output with logic.
# Hint: compare the population to attack proportion.

# It creates two dataframes us_count and us_pop storing the numbers of ZeroAccess attacks and the population of each state.
# Then it calculates the proportion of attacks to the population of each state and compare them.
# us_count dataframe contains the number of ZeroAccess attacks for each state.
# The att_pc column calculate the proportion of attacks for each state by dividing the attack column by the attack.sum() column therefore calculating the percentage of ZeroAccess attacks in a specific state.

us_count = us_df.groupby('State').size().sort_values(ascending=False).reset_index()
us_count.columns = ['state','attack']
us_count['att_pc'] = us_count['attack']/us_count.attack.sum()
us_count = us_count.set_index(us_count['state'])
us_count.drop(['state'],axis=1,inplace=True)
us_count

# The us_pop dataframe contains the population for each state.
# pop_pc column calculates the proportion of the population for each state by dividing the population column by the population.sum() column therefore pop_pc columnn represents the percentage of the total population in the state.

us_pop = state_df[['state','population']]
us_pop['pop_pc'] = state_df.population/state_df.population.sum()
us_pop = us_pop.set_index(us_pop['state'])
us_pop.drop(['state'],axis=1,inplace=True)
us_pop

# Conclusions
# comparing att_pc and pop_pc columns we can see that the number of ZeroAccess attacks is distributed relative to the population of each state.
# California which has the higher percentage of the population has also the higher percentage of attacks.

# Q6. How is the attack or infection rate in each state related to the state population? 
# What is the best plot to present these results with? 
# Plot it and explain the output with a valid explanation.

# As mentioned above there is a correlation between rate of attack and population. 
# I think the best plot is the scatter plot which show clearly the correlation between the two. 
# The results are clearly showing a positive correlation.

import matplotlib.pyplot as plt

# Merge the two DataFrames on the 'state' column
merged_df = pd.merge(us_count, us_pop, left_index=True, right_index=True)

# Scatter plot
plt.figure(figsize=(10, 6))
plt.scatter(merged_df['pop_pc'], merged_df['att_pc'], s=50, color='blue', alpha=0.7)

# Set labels and title
plt.xlabel('Population Percentage')
plt.ylabel('Attack Percentage')
plt.title('Attack Rate vs Population Rate in Each State')

# Annotate each point with the state name
for i, txt in enumerate(merged_df.index):
    plt.annotate(txt, (merged_df['pop_pc'][i], merged_df['att_pc'][i]), fontsize=8, ha='left')

plt.grid(True)
plt.show()


# Q7. Plot interactive bar plot for top 20 worst affected countries by covid-19 till date which shows the actual number of deaths and recovered covid-19 patients in that affected country based on hovering the mouse over the bar for that country.

#plot an interactive bar plot with the actual number of confirmed cases 
import plotly.express as px

sorted_country_df1 = country_df.sort_values('deaths', ascending = False).head(20)
sorted_country_df1

px.bar(
    sorted_country_df1.head(20),
    x = "country_region",
    #unable to use the recovered value 
    #since the dataset link provided from the website is showing all NaN values for recovered column
    y = "deaths",
    title = "Top 20 worst affected countries based on number of confirmed Covid-19 cases",
    color_discrete_sequence=["blue"],
    height = 500,
    width = 800
)
