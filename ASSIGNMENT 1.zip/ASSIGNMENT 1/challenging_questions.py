"""Challenging Questions


# D7055E - Challenging Questions
## Group 6



*   Donato Scarano - DONSCA-3
*   Jacob Yousif - JACYOU-0
*   Yuehua Qin - YUEQIN-9

## Importing libraries
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

"""## Loading the data

### Naming the datasheet, skipping first 20 rows and last 2 rows
"""

df = pd.read_excel(
    'https://s3-api.us-geo.objectstorage.softlayer.net/cf-courses-data/CognitiveClass/DV0101EN/labs/Data_Files/Canada.xlsx',
    sheet_name= 'Canada by Citizenship',
    skiprows=range(20),
    skipfooter=2)

"""## Organizing the data

### Dropping the unwanted columns
"""

df.drop(['AREA', 'REG', 'DEV', 'Type', 'Coverage'],axis=1, inplace=True)

"""### Renaming some of the columns"""

df.rename(columns={'OdName': 'Country', 'AreaName': 'Continent', 'RegName': 'Region'}, inplace=True)

"""## Setting the index"""

df = df.set_index('Country')

"""## Choosing ggplot"""

mpl.style.use(['ggplot'])

"""## Immigration By Continents"""

df['Total'] = (df.iloc[:,4:]).sum(axis=1)

"""## Dataframe: the total number of immigrants each year"""

years = list(range(1980, 2014))
df[years] = df[years].applymap(int)
totalPerYear = df[years].sum(axis=0).reset_index()
totalPerYear.columns = ['Year', 'Total']
totalPerYear['Year'] = totalPerYear['Year'].astype(int)
totalPerYear.reset_index(drop=True, inplace=True)

"""## Top 15"""

top = df.loc[['India', 'China', 'Pakistan', 'France'], years]
top = top.T

"""## Challenging Questions

### Q1
"""

cont = df.groupby('Continent', axis=0).sum(numeric_only=True)
pie_colors = ["lightgreen", "lightblue", "pink", "purple", "grey", "gold"]
explode = (0, 0.1, 0, 0, 0, 0)
cont['Total'].plot(kind='pie', figsize=(7, 7),
                   autopct='%1.1f%%', shadow=True,
                   explode=explode, colors=pie_colors,
                   startangle=30)
plt.title('Immigration By Continents')
plt.axis('equal')
plt.show()

"""### Q2"""

plt.figure(figsize=(10, 6))
plt.scatter(totalPerYear['Year'], totalPerYear['Total'], alpha=0.5, color='blue')
plt.title('Total Immigrants per Year')
plt.xlabel('Year')
plt.ylabel('Number of Immigrants')
plt.grid(True)
plt.show()

"""### Q3"""

top.plot(kind='area', stacked=True, figsize=(14, 6))
plt.title('Immigration trends')
plt.ylabel('Number of Immigrants')
plt.xlabel('Years')
plt.show()

"""### Q4"""

Iceland = df.loc['Iceland', years]
Iceland.plot(kind='bar', figsize=(14, 6))
plt.xlabel('Year')
plt.ylabel('Number of immigrants')
plt.title('Immigrants From Iceland')
plt.show()

"""### Q5"""

df_top15 = pd.DataFrame(df.nlargest(15, 'Total')['Total'].sort_values(ascending=True))
plot15 = df_top15.plot.barh(figsize=(14, 6), legend=False, color='crimson', edgecolor='LightCoral')
plot15.bar_label(plot15.containers[0], label_type='center')
plt.title('Top 15 Immigrant Countries to Canada from 1980-2013', color='black')
plt.xlabel('Number of Immigrants', color='black')
plt.ylabel('Country', color='black')
plt.xticks(color='black')
plt.yticks(color='black')
plt.show()