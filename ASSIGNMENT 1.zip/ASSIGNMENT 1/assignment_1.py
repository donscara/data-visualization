"""Assignment1


# D7055E - Assigment 1
## Group 6



*   Donato Scarano - DONSCA-3
*   Jacob Yousif - JACYOU-0
*   Yuehua Qin - YUEQIN-9

## Importing libraries
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

"""## Loading the data

### Naming the datasheet, skipping first 20 rows and last 2 rows
"""

df = pd.read_excel(
    'https://s3-api.us-geo.objectstorage.softlayer.net/cf-courses-data/CognitiveClass/DV0101EN/labs/Data_Files/Canada.xlsx',
    sheet_name= 'Canada by Citizenship',
    skiprows=range(20),
    skipfooter=2)

"""## Exploring the data"""

print(df.head())

print(df.tail())

print(df.describe())

print(df.columns)

"""## Organizing the data

### Dropping the unwanted columns
"""

df.drop(['AREA', 'REG', 'DEV', 'Type', 'Coverage'],axis=1, inplace=True)

"""### The data structure after dropping the columns"""

print(df.head())

print(df.columns)

"""### Renaming some of the columns"""

df.rename(columns={'OdName': 'Country', 'AreaName': 'Continent', 'RegName': 'Region'}, inplace=True)

"""### The columns after renaming"""

print(df.columns)

"""## Null values"""

print(df.isnull().any())

print(df.isnull().sum())

"""## Setting the index"""

df = df.set_index('Country')

"""## The available plots"""

print(plt.style.available)

"""## Choosing ggplot"""

mpl.style.use(['ggplot'])

"""## Switzerland's immigration tend to Canada by year"""

years = list(range(1980, 2014))
switzerland_data = df.loc['Switzerland', years]
plt.figure(figsize=(10, 6))
plt.plot(years, switzerland_data)
plt.title('Immigration from Switzerland to Canada (1980 - 2013)')
plt.xlabel('Year')
plt.ylabel('Number of Immigrants')
plt.grid(True)
plt.show()

"""## Immigration tend to Canada by year"""

ind_pak_ban = ['India', 'Pakistan', 'Bangladesh']
immigration_data = df.loc[ind_pak_ban, years].transpose()
immigration_data.plot(kind='line', figsize=(10, 6))
plt.title('Immigration trends to Canada from India, Pakistan, and Bangladesh (1980 - 2013)')
plt.ylabel('Number of Immigrants')
plt.xlabel('Year')
plt.show()

"""## Immigration By Continents"""

df['Total'] = (df.iloc[:,4:]).sum(axis=1)

print(df.head())

print(df)

cont = df.groupby('Continent', axis=0).sum(numeric_only=True)
cont['Total'].plot(kind='pie', figsize=(7, 7),
                   autopct='%1.1f%%',
                   shadow=True)
plt.title('Immigration By Continents')
plt.axis('equal')
plt.show()

"""## Chinese Immigrants to Canada from 1980 to 2013"""

china = df.loc[['China'],years].T
china.plot(kind='box', figsize=(8, 6))
plt.title('Chinese Immigrants')
plt.ylabel('Number of Immigrants')
plt.show()

"""## Immigrants of the subcontinent countries"""

ind_pak_ban = df.loc[['India', 'Pakistan', 'Bangladesh'], years]
ind_pak_ban.T.plot(kind='box', figsize=(8, 6))
plt.title('Box plot of Indian, Pakistan and Bangladesh Immigrants')
plt.ylabel('Number of Immigrants')
plt.show()

"""## Dataframe: the total number of immigrants each year"""

df[years] = df[years].applymap(int)
totalPerYear = df[years].sum(axis=0).reset_index()
totalPerYear.columns = ['Year', 'Total']
totalPerYear['Year'] = totalPerYear['Year'].astype(int)
totalPerYear.reset_index(drop=True, inplace=True)

print(totalPerYear)

"""## Top 15"""

top = df.loc[['India', 'China', 'Pakistan', 'France'], years]
top = top.T

print(top)

"""## Area plot"""

colors = ['Black', 'Green', 'Blue', 'Red']
top.plot(kind='area', stacked=False, figsize=(16,8))
plt.title('Immigration trend')
plt.ylabel('Number of Immigrants')
plt.xlabel('Years')
plt.show()

"""## Histogram"""

top.plot.hist(figsize=(14, 6))
plt.title('Histogram of Immigration from Some Populous Counties')
plt.ylabel('Number of Years')
plt.xlabel('Number of Immigrants')
plt.show()

"""## Specifying the number of bins as 15"""

cont, bin_edges = np.histogram(top,15)
top.plot(kind='hist',figsize=(14, 6), bins=15, alpha=0.6,
         xticks=bin_edges, color=colors)
plt.show()

"""##  Stacked plot of the histogram"""

top.plot(kind='hist', figsize=(14, 6), bins=15,
         xticks=bin_edges, color=colors, stacked=True)
plt.title('Histogram of Immigration from Some Populous Counties')
plt.ylabel('Number of Years')
plt.xlabel('Number of Immigrants')
plt.show()

"""##  The number of immigrants from France per year"""

france = df.loc['France', years]
france.plot(kind='bar', figsize=(14, 6))
plt.xlabel('Year')
plt.ylabel('Number of immigrants')
plt.title('Immigrants From France')
plt.show()

"""## Information Bar"""

france.plot(kind='bar', figsize=(14, 6))
plt.xlabel('Year')
plt.ylabel('Number of immigrants')
plt.title('Immigrants From France')
plt.annotate('Increasing Trend', xy=(19, 4500),
             rotation=23, va='bottom', ha='left')
plt.annotate('', xy=(29,5500), xytext=(17, 3800),
             xycoords='data', arrowprops=dict(arrowstyle='->',
                                              connectionstyle='arc3',
                                              color='black',
                                              lw=1.5))
plt.show()

"""## Horizontal bar plot with the labels"""

df_top10 = pd.DataFrame(df.nlargest(10, 'Total')['Total'].sort_values(ascending=True))
df_top10.plot.barh(figsize=(12, 6), legend=False, color='crimson', edgecolor='LightCoral')
plt.title('Top 10 Immigrant Countries to Canada from 1980-2013', color='black')
plt.xlabel('Number of Immigrants', color='black')
plt.ylabel('Country', color='black')
plt.xticks(color='black')
plt.yticks(color='black')
plt.show()
