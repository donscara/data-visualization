"""
# D7055E - Assigment 2
## Group 6
*   Donato Scarano - DONSCA-3
*   Jacob Yousif - JACYOU-0
*   Yuehua Qin - YUEQIN-9
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import requests
from io import BytesIO
import zipfile
from nibabel.analyze import AnalyzeImage
import geoplot as gplt
import geopandas as gpd
import geoplot.crs as gcrs
import pandas as pd
import matplotlib.pyplot as plt
import pycountry
import plotly.express as px
from nibabel import FileHolder
import re
import warnings

warnings.simplefilter(action='ignore', category=FutureWarning)
pd.options.mode.chained_assignment = None

"""## Pre-defined methods"""

def get_mediafire_download_link(url):
    """ Get the actual download link from a MediaFire page """
    response = requests.get(url)
    response.raise_for_status()
    match = re.search(r'href="(https?://download[^"]+)"', response.text)
    if match:
        return match.group(1)
    else:
        raise ValueError("Download link not found")

def download_zip_from_mediafire(url):
    """ Download a ZIP file from MediaFire """
    download_url = get_mediafire_download_link(url)
    response = requests.get(download_url, stream=True)
    response.raise_for_status()
    return BytesIO(response.content)

"""## 3.1 Spatial Data Visualization

### 3.1.2
"""

rows = 10
columns = 15
x, y = np.meshgrid(np.linspace(-1, 1, columns), np.linspace(-1, 1, rows))
d= np.sqrt(x*x+y*y)
sigma = 0.5
gaussian_disc = (8*np.exp(-((d)**2/(2*sigma**2)))).astype('uint8')
print(gaussian_disc)

"""### 3.1.3"""

x = 3
y = 5
print(gaussian_disc[x, y])

"""### 3.1.5

The following two subplots represent a grayscale image and a heatmap of a Gaussian disc's array with values somewhere in the range of 0 and 8 with 10 rows and 15 columns.
"""

f, axes = plt.subplots(1, 2, figsize=(12, 6))
(a_grayscale, a_heatmap) = axes
a_grayscale.imshow(gaussian_disc, cmap="gray")
a_grayscale.axis('off')
a_grayscale.set_title("Grayscale Image")
sns.heatmap(gaussian_disc, cmap="viridis", square=True, annot=True, ax=a_heatmap)
a_heatmap.set_ylim(gaussian_disc.shape[0], 0)
a_heatmap.invert_yaxis()
a_heatmap.set_ylabel("X")
a_heatmap.set_xlabel("Y")
a_heatmap.set_title("Heatmap Image")
plt.tight_layout()


"""### 3.1.6"""

rows = 10
columns = 15
x, y = np.meshgrid(np.linspace(-1, 1, columns), np.linspace(-1, 1, rows))
d= np.sqrt(x*x+y*y)
sigma = 0.5
disc = (8*np.exp(-((d)**2/(2.0 *sigma**2) ))).astype('uint')
rgb_color_array = np.stack([disc, np.roll(disc, 2, axis=0), np.roll(disc, 2, axis=1)], axis=2)
print("Red:")
print(rgb_color_array[:,:,1])

"""### 3.1.7

The following six subplots represent a Gaussian disc's array with six different color mappings,they are: gray, gray-scaled, Viridis, Hot, diverging colormap and HSV.
"""

rows = 10
columns = 15
x, y = np.meshgrid(np.linspace(-1, 1, columns), np.linspace(-1, 1, rows))
d= np.sqrt(x*x+y*y)
_12_bit_array = ((2**12-1)*np.exp(-((d)**2/(2.0 *sigma**2) ))).astype('uint16')

f,axes = plt.subplots(2,3)
(a_g, a_s, a_v, a_h, a_rb, a_hsv) = axes.flatten()

a_g.imshow(_12_bit_array, cmap="gray", vmin=0, vmax=(2**16)-1)
a_g.set_axis_off()
a_g.set_title("Gray")

a_s.imshow(_12_bit_array, cmap="gray")
a_s.set_axis_off()
a_s.set_title("Gray-scaled")

a_v.imshow(_12_bit_array, cmap="viridis")
a_v.set_axis_off()
a_v.set_title("Viridis")

a_h.imshow(_12_bit_array, cmap="hot")
a_h.set_axis_off()
a_h.set_title("Hot-squential-colormap")

a_rb.imshow(_12_bit_array, cmap="RdBu")
a_rb.set_axis_off()
a_rb.set_title("diverging colormap")

a_hsv.imshow(_12_bit_array, cmap="hsv")
a_hsv.set_axis_off()
a_hsv.set_title("HSV (not perceptually uniform)")


"""## 3.2

### 3.2.2
"""

url = 'https://www.mediafire.com/file/y7x0srsm78ss0do/MRI-Dataset.zip/file'
zip_file = download_zip_from_mediafire(url)
zf = zipfile.ZipFile(zip_file)
print(zf)
print(type(zf))

"""### 3.2.3"""

header = BytesIO(zf.open('attention/structural/nsM00587_0002.hdr').read())
image = BytesIO(zf.open('attention/structural/nsM00587_0002.img').read())
img = AnalyzeImage.from_file_map({'header':FileHolder(fileobj=header), 'image':FileHolder(fileobj=image)})
arr = img.get_fdata()
print('MRI')
print(arr.shape)
print(arr)

"""### 3.2.5

The following plot is a horizontal slice of the brain to the screen.
"""

plt.figure()
plt.imshow(arr[:, :, 5])
plt.colorbar()


"""## 3.3"""



usa = gpd.read_file('data/US_State.shp')

print(usa.columns)
print(usa.head())

usa.to_csv('my_data.csv', index=False)
state_pop = pd.read_csv('us_state_est_population.csv')
print(state_pop.head())

pop_states = usa.merge(state_pop, left_on="StateName", right_on="NAME")
print(pop_states.head())

"""The following plot is shape of California, USA."""

pop_states[pop_states.NAME=='California'].plot()
path = gplt.datasets.get_path('contiguous_usa')
contiguous_usa = gpd.read_file(path)
print(contiguous_usa.head())

"""The following plot is the map of USA, organized by states."""

gplt.polyplot(contiguous_usa)
path = gplt.datasets.get_path('usa_cities')
usa_cities = gpd.read_file(path)
print(usa_cities.head())

continental_usa_cities = usa_cities.query('STATE not in ["HI", "AK", "PR"]')
gplt.pointplot(continental_usa_cities)
print(continental_usa_cities)

ax = gplt.polyplot(contiguous_usa)
gplt.pointplot(continental_usa_cities, ax=ax)

ax = gplt.polyplot(contiguous_usa, projection=gcrs.AlbersEqualArea())
gplt.pointplot(continental_usa_cities, ax=ax)

ax = gplt.polyplot(contiguous_usa, projection=gcrs.AlbersEqualArea())
gplt.pointplot(
    continental_usa_cities,
    ax=ax,
    hue='ELEV_IN_FT',
    legend=True
)

ax = gplt.polyplot(
    contiguous_usa,
    edgecolor='white',
    facecolor='lightgray',
    figsize=(12, 8),
    projection=gcrs.AlbersEqualArea()
)

gplt.pointplot(
    continental_usa_cities,
    ax=ax,
    hue='ELEV_IN_FT',
    cmap='Blues',
    scheme='quantiles',
    scale='ELEV_IN_FT',
    limits=(1, 10),
    legend=True,
    legend_var='scale',
    legend_kwargs={'frameon': False},
    legend_values=[-110, 1750, 3600, 5500, 7400],
    legend_labels=['-110 feet', '1750 feet', '3600 feet', '5500 feet', '7400 feet']
)

ax.set_title('Cities in the continental US, by elevation', fontsize=16)

ax = gplt.polyplot(contiguous_usa, projection=gcrs.AlbersEqualArea())
gplt.choropleth(
    contiguous_usa,
    ax=ax,
    hue='population',
    edgecolor='white',
    linewidth=1,
    cmap='Greens',
    legend=True,
    scheme='FisherJenks',
    legend_labels=['<3 millions', '3-6.7 million', '6.7-12.0 million',
                   '12.8-25 million', '25-37 million'],
    projection=gcrs.AlbersEqualArea()
)

obesity = pd.read_csv('National_Obesity_By_State.csv', sep=',')
print(obesity.head())
print(contiguous_usa.columns)
print(obesity.columns)

geo_obesity = contiguous_usa.set_index('state').join(obesity.set_index('NAME'))
print(geo_obesity.head())

gplt.cartogram(
    geo_obesity,
    scale='Obesity',
    projection=gcrs.AlbersEqualArea()
)

melbourne = gpd.read_file(gplt.datasets.get_path('melbourne'))
df = gpd.read_file(gplt.datasets.get_path('melbourne_schools'))
melbourne_primary_schools = df.query('School_Type == "Primary"')

ax = gplt.voronoi(
    melbourne_primary_schools,
    clip=melbourne,
    linewidth=0.5,
    edgecolor='white',
    projection=gcrs.Mercator()
)

gplt.polyplot(
    melbourne,
    edgecolor='None',
    facecolor='lightgray',
    ax=ax
)

gplt.pointplot(
    melbourne_primary_schools,
    color='black',
    ax=ax,
    s=1,
    extent=melbourne.total_bounds
)

plt.title('Primary Schools in Greater Melbourne, 2018')
plt.show()
"""## 3.4"""

df_confirmedGlobal = pd.read_csv('covid19/time_series_covid19_confirmed_global.csv')
print(df_confirmedGlobal.head())

df_confirmedGlobal = df_confirmedGlobal.drop(columns=['Province/State', 'Lat', 'Long'])
df_confirmedGlobal = df_confirmedGlobal.groupby('Country/Region').agg('sum')
date_list = list(df_confirmedGlobal.columns)

def get_country_code(name):
    try:
        return pycountry.countries.lookup(name).alpha_3
    except:
        return None

df_confirmedGlobal['country'] = df_confirmedGlobal.index
df_confirmedGlobal['iso_alpha_3'] = df_confirmedGlobal['country'].apply(get_country_code)

df_long = pd.melt(df_confirmedGlobal, id_vars=['country', 'iso_alpha_3'], value_vars=date_list)
print(df_long)

"""The following map is an animated choropleth map illustrating the evolution of confirmed COVID-19 cases worldwide 
from January 20, 2020, to November 9, 2020. Initially, confirmed cases were primarily concentrated in China. From March onwards,
 Italy led the surge in confirmed cases, followed by other European countries. Simultaneously, in the Americas, the United States 
 took the lead, with subsequently increasing confirmed cases in other countries. Due to the lack of confirmed case data for some countries, 
 such as Russia, the changes in confirmed cases for these nations cannot be observed on the map."""

fig = px.choropleth(df_long,
                    locations="iso_alpha_3",
                    color="value",
                    hover_name="country",
                    animation_frame="variable",
                    projection="natural earth",
                    color_continuous_scale="Peach",
                    range_color=[0, 50000])
fig.show()
fig.write_html("Covid19_map.html")