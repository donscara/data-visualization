# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
# create a Gaussian disc array with values in the range of 0 and 8 with 
# 10 rows and 15 columns

import numpy as np

rows=10
columns=15

x,y = np.meshgrid(np.linspace(-1,1,columns),np.linspace(-1,1,columns))

d = np.sqrt(x*x + y*y)

sigma = 0.5

myGaussianDisc = (8*np.exp(-((d)**2/(2.0 * sigma**2)))).astype('uint8')

display(myGaussianDisc)

# extract values at x=3 and y=5

x=3
y=5

display("number=", myGaussianDisc[x,y])

#Import Matplotlib and seaborn
import matplotlib.pyplot as plt
import seaborn as sns

#Display the arrays as a grayscale image
f,axes = plt.subplots(1,2)
(aGrayscale,aHeatmap) = axes.flatten()

aGrayscale.imshow(myGaussianDisc, cmap='gray')
aGrayscale.set_axis_off()
aGrayscale.set_title('Grayscale Image')

#display the arrays as a heatmap
sns.heatmap(myGaussianDisc,cmap="viridis",square=True,annot=True,ax=aHeatmap)
aHeatmap.set_ylim(0,10)
aHeatmap.invert_yaxis()
aHeatmap.set_ylabel('X')
aHeatmap.set_xlabel('Y')
aHeatmap.set_title("Heatmap Image")

plt.show()

#color images using a 3-channel Gaussian disc's array with values in the range of 0 to 8 with 10 rows and 15 columns.

rows=10
columns=15

x,y = np.meshgrid(np.linspace(-1,1,columns), np.linspace(-1,1,rows))
d=np.sqrt(x*x+y*y)
sigma=0.5
disc = (8*np.exp(-((d)**2/(2.0*sigma**2)))).astype('uint')
myRGBColorArray = np.stack([disc,np.roll(disc,2,axis=0),np.roll(disc,2,axis=1)],axis=2)
                            
print('Red:')
display(myRGBColorArray[:,:,1])

#create other plots (Gray,Grayscale, Viridis, Hot-Sequential Colormap, Diverging colormap, HSV(not perceptually uniform))

rows=10
columns=15

x,y = np.meshgrid(np.linspace(-1,1,columns), np.linspace(-1,1,rows))
d=np.sqrt(x*x+y*y)
sigma=0.5
my12BitArray = ((2**12-1)*np.exp(-((d)**2/(2.0*sigma*2)))).astype('uint16')

f,axes = plt.subplots(2,3)
(aG, aS, aV, aH, aRB, aHSV) = axes.flatten()

aG.imshow(my12BitArray,cmap="gray", vmin=0,vmax=(2**16)-1)
aG.set_axis_off()
aG.set_title("Gray")

aS.imshow(my12BitArray,cmap="gray")
aS.set_axis_off()
aS.set_title("Gray-Scaled")

aV.imshow(my12BitArray,cmap="viridis")
aV.set_axis_off()
aV.set_title("Viridis")

aH.imshow(my12BitArray,cmap="hot")
aH.set_axis_off()
aH.set_title("Hot Sequential")

aRB.imshow(my12BitArray,cmap="RdBu")
aRB.set_axis_off()
aRB.set_title("Diverging")

aHSV.imshow(my12BitArray,cmap="hsv")
aHSV.set_axis_off()
aHSV.set_title("HSV")

plt.show()

#import MRI Dataset

#import requests
#images=requests.get('https://drive.google.com/file/d/1y8JFmRr_nfDAV7waJ4HaHsChTkdR3U4H/view?usp=drive_link')

#import zipfile
#from io import BytesIO

#zipstream = BytesIO(images.content)
#zf = zipfile.ZipFile(zipstream)

#from nibabel import FileHolder
#from nibabel.analyze import AnalyzeImage

#header = BytesIO(zf.open('https://drive.google.com/file/d/1y8JFmRr_nfDAV7waJ4HaHsChTkdR3U4H/view?usp=drive_link/attention/structural/nsM00587_0002.hdr').read())
#image = BytesIO(zf.open('https://drive.google.com/file/d/1y8JFmRr_nfDAV7waJ4HaHsChTkdR3U4H/view?usp=drive_link/attention/structural/nsM00587_0002.img').read())
#img = AnalyzeImage.from_file_map({'header':FileHolder(fileobj=header),'image':FileHolder(fileobj=image)})
#arr=img.get_fdata()
#arr.shape

#import matplotlib.pyplot as plt
#%matplotlib inline
#plt.imshow(arr[:,:,5])
#plt.colorbar()
#plt.plot()

#4.5 VISUALIZING GEOSPATIAL DATA

import geoplot as gplt
import geopandas as gpd
import geoplot.crs as gcrs
import imageio
import pandas as pd
import pathlib
import matplotlib.animation as animation
import matplotlib.pyplot as plt
import mapclassify as mc
import numpy as np
#import pycountry
import plotly.express as px

%matplotlib inline

usa = gpd.read_file("https://drive.google.com/file/d/19IEH2FI2FFjF6rvaMXE3ZV7DJlMnZVcD/view?usp=drive_link")
print(usa.head())

