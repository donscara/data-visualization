"""
# D7055E - Assigment 2 - Challenging Questions
## Group 6
*   Donato Scarano - DONSCA-3
*   Jacob Yousif - JACYOU-0
*   Yuehua Qin - YUEQIN-9
"""

import numpy as np
import matplotlib.pyplot as plt
import geoplot as gplt
import geopandas as gpd
import geoplot.crs as gcrs
import pandas as pd
import matplotlib.pyplot as plt
import pycountry
import plotly.express as px
import warnings

warnings.simplefilter(action='ignore', category=FutureWarning)
pd.options.mode.chained_assignment = None

path = gplt.datasets.get_path('contiguous_usa')
contiguous_usa = gpd.read_file(path)
path = gplt.datasets.get_path('usa_cities')
usa_cities = gpd.read_file(path)
continental_usa_cities = usa_cities.query('STATE not in ["HI", "AK", "PR"]')

"""## Challenging Questions

### Q1
"""

rows = 10
columns = 15
x, y = np.meshgrid(np.linspace(-1, 1, columns), np.linspace(-1, 1, rows))
d= np.sqrt(x*x+y*y)
sigma = 0.5
disc = (8*np.exp(-((d)**2/(2.0 *sigma**2) ))).astype('uint')
rgb_color_array = np.stack([disc, np.roll(disc, 2, axis=0), np.roll(disc, 2, axis=1)], axis=2)

fig, axs = plt.subplots(2, 2, figsize=(10, 10))
red_channel = rgb_color_array[:, :, 0]
axs[0, 0].imshow(red_channel, cmap='Reds')
axs[0, 0].set_title('Red Channel')
axs[0, 0].axis('off')
green_channel = rgb_color_array[:, :, 1]
axs[0, 1].imshow(green_channel, cmap='Greens')
axs[0, 1].set_title('Green Channel')
axs[0, 1].axis('off')
blue_channel = rgb_color_array[:, :, 2]
axs[1, 0].imshow(blue_channel, cmap='Blues')
axs[1, 0].set_title('Blue Channel')
axs[1, 0].axis('off')
composite_image = rgb_color_array
axs[1, 1].imshow(composite_image)
axs[1, 1].set_title('Composite Image')
axs[1, 1].axis('off')
plt.tight_layout()

"""### Q2

A quantile is an equal part of a dataset or based on other aspects such as percentiles. When it comes to Visualization, 
quantiles help to group the data into different groups and they can be colored accordingly to distinguish the different groups 
to identify patterns and to interpret the data intuitively. A simple and practical example is to identify for instance outliers. 
Hence, quantiles provide details. In this task it was utilized for the choropleth maps, each quantile is represented by a different color.

### Q3
"""

ax = gplt.polyplot(
    contiguous_usa,
    edgecolor='white',
    facecolor='lightgray',
    figsize=(12, 8),
    projection=gcrs.AlbersEqualArea()
)

continental_usa_cities['quantile'] = pd.qcut(continental_usa_cities['POP_2010'], 10, labels=[i for i in range(1, 11)])
quantile_ranges = pd.qcut(continental_usa_cities['POP_2010'], 10, retbins=True)[1]
legend_labels = []

for i in range(len(quantile_ranges) - 1):
    label = f'{int(quantile_ranges[i])} - {int(quantile_ranges[i + 1])}'
    legend_labels.append(label)

gplt.pointplot(
    continental_usa_cities,
    ax=ax,
    hue='quantile',
    cmap='Blues',
    scheme='quantiles',
    scale='quantile',
    limits=(1, 10),
    legend=True,
    legend_var='scale',
    legend_kwargs={'frameon': False},
    legend_values = list(range(1, 11)),
    legend_labels = legend_labels
)

ax.set_title('US Cities:  10 Quantiles', fontsize=16)

"""### Q4"""

ax = gplt.voronoi(
    continental_usa_cities,
    clip=contiguous_usa,
    hue='ELEV_IN_FT',
    cmap='Blues',
    linewidth=0.5,
    edgecolor='white',
    projection=gcrs.AlbersEqualArea()
)

gplt.polyplot(
    contiguous_usa,
    edgecolor='None',
    facecolor='lightgray',
    ax=ax
)

gplt.pointplot(
    continental_usa_cities,
    color='black',
    ax=ax,
    s=1,
    extent=contiguous_usa.total_bounds
)

sm = plt.cm.ScalarMappable(cmap='Blues', norm=plt.Normalize(vmin=continental_usa_cities['ELEV_IN_FT'].min(), vmax=continental_usa_cities['ELEV_IN_FT'].max()))
cb = plt.colorbar(sm, ax=ax)
plt.title('US Cities by elevation')
plt.show()

"""### Q5"""

df_recovered = pd.read_csv('covid19/time_series_covid19_recovered_global.csv')
print(df_recovered.head())

df_recovered = df_recovered.drop(columns=['Province/State', 'Lat', 'Long'])
df_recovered = df_recovered.groupby('Country/Region').agg('sum')
date_list = list(df_recovered.columns)

def get_country_code(name):
    try:
        return pycountry.countries.lookup(name).alpha_3
    except:
        return None

df_recovered['country'] = df_recovered.index
df_recovered['iso_alpha_3'] = df_recovered['country'].apply(get_country_code)
df_long = pd.melt(df_recovered, id_vars=['country', 'iso_alpha_3'], value_vars=date_list)
print(df_long)

"""The following map is an animated choropleth representation depicting the progression of the global COVID-19 recovery count, 
spanning from January 20, 2020, to November 9, 2020. This animated map showcases the evolving numbers of individuals recovering from the virus across the world during this period.
The earliest recovered cases of COVID-19 were predominantly concentrated in China, with the number of recoveries rapidly increasing. By March, the recovery count in China had 
surpassed 50,000 individuals. Starting from April, the number of recoveries in Europe and the Americas also began to rise gradually. However, data for some countries is still 
lacking, such as Russia, making it impossible to depict the situation of these countries on the map.
"""

fig = px.choropleth(df_long,
                    locations="iso_alpha_3",
                    color="value",
                    hover_name="country",
                    animation_frame="variable",
                    projection="natural earth",
                    color_continuous_scale="Greens",
                    range_color=[0, 50000])
fig.show()
fig.write_html("Covid19_map.html")

"""### Q6"""

df_deaths = pd.read_csv('covid19/time_series_covid19_deaths_global.csv')
print(df_deaths.head())

df_deaths = df_deaths.drop(columns=['Province/State', 'Lat', 'Long'])
df_deaths = df_deaths.groupby('Country/Region').agg('sum')
date_list = list(df_deaths.columns)

def get_country_code(name):
    try:
        return pycountry.countries.lookup(name).alpha_3
    except:
        return None

df_deaths['country'] = df_deaths.index
df_deaths['iso_alpha_3'] = df_deaths['country'].apply(get_country_code)
df_long = pd.melt(df_deaths, id_vars=['country', 'iso_alpha_3'], value_vars=date_list)
print(df_long)

"""The map below is an animated choropleth representation illustrating the progression of global COVID-19-related deaths from January 20, 2020, to November 9, 2020.
From a data perspective, although China was the first country to report COVID-19 fatalities, it does not have the highest death toll. The United States witnessed 
a rapid surge in death numbers, surpassing 50,000 in April. In Asia, Thailand, in Europe, the United Kingdom, and in South America, Brazil, also experienced death tolls exceeding 50,000.
"""

fig = px.choropleth(df_long,
                    locations="iso_alpha_3",
                    color="value",
                    hover_name="country",
                    animation_frame="variable",
                    projection="natural earth",
                    color_continuous_scale="Reds",
                    range_color=[0, 50000])
fig.show()
fig.write_html("Covid19_map.html")